// import logo from './logo.svg';
import './App.css';
// import {Routes,BrowserRouter} from 'react-router-dom'
import Home from './Components/Home'
import Lifecycle from './Components/LifeCycle';
import ParentComponent from './Components/ParentComponent';
import RenderHome from './Routing/RenderHome';
import NavRoute from './Navbar/NavRoute';

function App() {
  return (
    <div className="App">
      {/* <Home color='green'/>
      <Lifecycle/>
      <ParentComponent/>
      <RenderHome/> */}
      <NavRoute/>
    </div>
  );
}

export default App;
