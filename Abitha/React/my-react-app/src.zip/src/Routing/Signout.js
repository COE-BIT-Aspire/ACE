import React from 'react';

function Signout({ onSignOut }) {
  return <button onClick={onSignOut}>Sign Out</button>;
}

export default Signout;
